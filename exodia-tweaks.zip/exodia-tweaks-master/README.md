# exodia-tweaks
exodia-tweaks to control performance/powerSave
