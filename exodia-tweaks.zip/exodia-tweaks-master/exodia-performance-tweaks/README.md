# exodia-performance-tweaks
performance-tweaks for Exodia OS to get high performance
