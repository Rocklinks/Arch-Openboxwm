# exodia-powersave-tweaks
powersave-tweaks for Exodia OS to save power
