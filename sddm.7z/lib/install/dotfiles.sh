#!/bin/bash

# ----------------------------------------------------- 
# Load automation variables
# ----------------------------------------------------- 

# Install SDDM
# -----------------------------------------------------
source $install_directory/dotfiles/sddm.sh

# ----------------------------------------------------- 
# Install SDDM Theme
# -----------------------------------------------------
source $install_directory/dotfiles/sddm-theme.sh


