#!/bin/bash
sleep 1

_checkSddm() {
    if [ -f /etc/systemd/system/display-manager.service ]; then
        echo "Enabled"
    else
        echo "Not enabled"
    fi
}

_checkSddmTheme() {
    if [ -d /usr/share/sddm/themes/sequoia ]; then
        echo "Installed"
    else
        echo "Not installed"
    fi
}


_selectCategory() {
    clear
    echo -e "${GREEN}"
    figlet -f smslant "Options"

    echo "- SDDM:" $(_checkSddm) "/ SDDM Theme:" $(_checkSddmTheme)    
   
    echo
   
    case ${category} in
       
        ;;
        "sddm toggle")
            source $options_directory/options/sddm.sh
        ;;
        "sddm theme")
            source $options_directory/options/sddm-theme.sh
        ;;
        REBOOT)
            reboot
        ;;
        CANCEL)
            exit
        ;;
        *)
            exit
        ;;
    esac
}

_selectCategory
